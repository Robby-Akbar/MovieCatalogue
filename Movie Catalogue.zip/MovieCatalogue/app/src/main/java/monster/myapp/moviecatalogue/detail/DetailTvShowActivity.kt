package monster.myapp.moviecatalogue.detail

import android.graphics.Bitmap
import android.os.Bundle
import android.view.Menu
import android.view.MenuItem
import android.view.MotionEvent
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import androidx.core.content.ContextCompat
import androidx.core.graphics.drawable.RoundedBitmapDrawableFactory
import androidx.core.view.GestureDetectorCompat
import com.bumptech.glide.Glide
import com.bumptech.glide.Priority
import com.bumptech.glide.request.RequestOptions
import com.bumptech.glide.request.target.BitmapImageViewTarget
import com.faltenreich.skeletonlayout.Skeleton
import com.faltenreich.skeletonlayout.createSkeleton
import monster.myapp.moviecatalogue.BuildConfig
import monster.myapp.moviecatalogue.R
import monster.myapp.moviecatalogue.core.data.Resource
import monster.myapp.moviecatalogue.core.domain.model.TvShow
import monster.myapp.moviecatalogue.core.utils.AppUtils
import monster.myapp.moviecatalogue.core.utils.MyGestureListener
import monster.myapp.moviecatalogue.core.utils.SwipeGestureListener
import monster.myapp.moviecatalogue.databinding.ActivityDetailTvBinding
import org.koin.androidx.viewmodel.ext.android.viewModel

class DetailTvShowActivity : AppCompatActivity() {

    companion object {
        const val EXTRA_ID = "extra_id"
        const val EXTRA_LIST_ID = "extra_list_id"
    }

    private lateinit var binding: ActivityDetailTvBinding
    private lateinit var tv: TvShow

    private val detailCatalogueViewModel: DetailCatalogueViewModel by viewModel()
    private lateinit var skeletonDetail: Skeleton
    private var menu: Menu? = null

    private lateinit var detector: GestureDetectorCompat
    private lateinit var listOfId: ArrayList<Int>

    private var position = 0
    private var swipedRight = false
    private var swipedLeft = false

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityDetailTvBinding.inflate(layoutInflater)
        setContentView(binding.root)

        val extras = intent.extras
        if (extras != null) {
            val id = extras.getInt(EXTRA_ID)
            listOfId = extras.getIntegerArrayList(EXTRA_LIST_ID) as ArrayList<Int>

            detailCatalogueViewModel.setSelectedCatalogue(id)
        }

        skeletonDetail = binding.cardDetail.createSkeleton()
        detailCatalogueViewModel.tvShow.observe(this, { tvShow ->
            if (tvShow != null) {
                when (tvShow) {
                    is Resource.Loading -> skeletonDetail.showSkeleton()
                    is Resource.Success -> if (tvShow.data != null) {
                        skeletonDetail.showOriginal()
                        tvShow.data?.let {
                            this.tv = it
                        }
                        setObjectData()
                        setSwipeNextPrevState()
                    }
                    is Resource.Error -> {
                        skeletonDetail.showOriginal()
                        Toast.makeText(this, tvShow.message, Toast.LENGTH_SHORT).show()
                    }
                }
            }
        })

        detector = GestureDetectorCompat(this, MyGestureListener(object : SwipeGestureListener {
            override fun onSwipeRight() {
                if (swipedRight) detailCatalogueViewModel.setSelectedCatalogue(listOfId[position - 1])
                else Toast.makeText(
                    this@DetailTvShowActivity, getString(R.string.msg_first), Toast.LENGTH_SHORT
                ).show()
            }

            override fun onLeftSwipe() {
                if (swipedLeft) detailCatalogueViewModel.setSelectedCatalogue(listOfId[position + 1])
                else Toast.makeText(
                    this@DetailTvShowActivity, getString(R.string.msg_last), Toast.LENGTH_SHORT
                ).show()
            }

            override fun onSwipeTop() {}
            override fun onSwipeBottom() {}
        }))

        setSupportActionBar(binding.toolbar)
        supportActionBar?.setDisplayHomeAsUpEnabled(true)
    }

    override fun dispatchTouchEvent(ev: MotionEvent?): Boolean {
        detector.onTouchEvent(ev)
        return super.dispatchTouchEvent(ev)
    }

    override fun onCreateOptionsMenu(menu: Menu): Boolean {
        menuInflater.inflate(R.menu.menu_detail, menu)
        this.menu = menu
        detailCatalogueViewModel.tvShow.observe(this, { tvShow ->
            if (tvShow != null) {
                when (tvShow) {
                    is Resource.Loading -> skeletonDetail.showSkeleton()
                    is Resource.Success -> if (tvShow.data != null) {
                        skeletonDetail.showOriginal()
                        tvShow.data?.favored?.let {
                            setFavoriteState(it)
                        }
                    }
                    is Resource.Error -> {
                        skeletonDetail.showOriginal()
                        Toast.makeText(this, tvShow.message, Toast.LENGTH_SHORT).show()
                    }
                }
            }
        })
        return true
    }

    override fun onOptionsItemSelected(item: MenuItem): Boolean {
        if (item.itemId == R.id.action_favorite) {
            detailCatalogueViewModel.setFavoredTvShow()
        } else if (item.itemId == android.R.id.home) {
            onBackPressed()
        }
        return super.onOptionsItemSelected(item)
    }

    private fun setObjectData() {
        binding.apply {
            Glide.with(this@DetailTvShowActivity)
                .load(BuildConfig.IMG_URL + tv.backdrop_path)
                .placeholder(R.drawable.ic_image_search)
                .error(R.drawable.ic_broken_image)
                .into(imgBackdrop)

            val options: RequestOptions = RequestOptions()
                .fitCenter()
                .placeholder(R.drawable.ic_image_search)
                .error(R.drawable.ic_broken_image)
                .priority(Priority.HIGH)

            Glide.with(this@DetailTvShowActivity)
                .asBitmap()
                .apply(options)
                .load(BuildConfig.IMG_URL + tv.poster_path)
                .into(object : BitmapImageViewTarget(imgPoster) {
                    override fun setResource(resource: Bitmap?) {
                        val circularBitmapDrawable =
                            RoundedBitmapDrawableFactory.create(
                                this@DetailTvShowActivity.resources,
                                resource
                            )
                        circularBitmapDrawable.isCircular = true
                        imgPoster.setImageDrawable(circularBitmapDrawable)
                    }
                })

            toolbarLayout.title = tv.name
            toolbarLayout.isSelected = true
            tvItemPopularity.text = tv.vote_average.toString()
            tvItemRelease.text = AppUtils.formatDate(tv.first_air_date)
            tvItemOverview.text = tv.overview
        }
    }

    private fun setFavoriteState(state: Boolean) {
        if (menu == null) return
        val menuItem = menu?.findItem(R.id.action_favorite)
        if (state) {
            menuItem?.icon = ContextCompat.getDrawable(this, R.drawable.ic_favored)
        } else {
            menuItem?.icon = ContextCompat.getDrawable(this, R.drawable.ic_favorite)
        }
    }

    private fun setSwipeNextPrevState() {
        for ((index, id) in listOfId.withIndex()) {
            if (id == tv.id) {
                position = index
            }
        }

        when (position) {
            0 -> {
                swipedRight = false
                swipedLeft = listOfId.size - 1 != 0
            }
            listOfId.size - 1 -> {
                swipedRight = true
                swipedLeft = false
            }
            else -> {
                swipedRight = true
                swipedLeft = true
            }
        }
    }
}