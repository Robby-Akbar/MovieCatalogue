package monster.myapp.moviecatalogue.catalogue.movie

import androidx.lifecycle.MutableLiveData
import androidx.lifecycle.Transformations
import androidx.lifecycle.ViewModel
import androidx.lifecycle.asLiveData
import monster.myapp.moviecatalogue.core.domain.model.Movie
import monster.myapp.moviecatalogue.core.domain.usecase.CatalogueUseCase
import monster.myapp.moviecatalogue.core.utils.DoubleTrigger

/**
 * Created by robby on 06/05/21.
 */
class MovieViewModel(private val catalogueUseCase: CatalogueUseCase) : ViewModel() {

    val isRefresh = MutableLiveData<Boolean>().apply { postValue(false) }
    val query = MutableLiveData<String>().apply { postValue("SELECT * FROM movie_entities") }

    var movies = Transformations.switchMap(DoubleTrigger(isRefresh, query)) {
        it.second?.let { it1 ->
            it.first?.let { it2 ->
                catalogueUseCase.getAllMovies(it2, it1).asLiveData()
            }
        }
    }

    fun getFavoredMovies() = catalogueUseCase.getFavoredMovies().asLiveData()

    fun setFavorite(movie: Movie, newState: Boolean) {
        catalogueUseCase.setFavoredMovie(movie, newState)
    }

}