package monster.myapp.moviecatalogue.catalogue.movie

import android.app.SearchManager
import android.content.Context
import android.content.Intent
import android.graphics.Color
import android.os.Bundle
import android.view.*
import android.widget.LinearLayout
import android.widget.Toast
import androidx.appcompat.widget.SearchView
import androidx.core.app.ShareCompat
import androidx.core.content.ContextCompat
import androidx.fragment.app.Fragment
import androidx.lifecycle.lifecycleScope
import androidx.paging.LoadState
import androidx.recyclerview.widget.LinearLayoutManager
import kotlinx.coroutines.flow.collectLatest
import kotlinx.coroutines.launch
import monster.myapp.moviecatalogue.R
import monster.myapp.moviecatalogue.core.data.Resource
import monster.myapp.moviecatalogue.core.domain.model.Movie
import monster.myapp.moviecatalogue.core.ui.ItemMovieCallback
import monster.myapp.moviecatalogue.core.ui.MovieAdapter
import monster.myapp.moviecatalogue.databinding.FragmentCatalogueBinding
import monster.myapp.moviecatalogue.detail.DetailMovieActivity
import monster.myapp.moviecatalogue.main.MainActivity
import org.koin.androidx.viewmodel.ext.android.viewModel

class MovieFragment : Fragment(), ItemMovieCallback {

    private var _binding: FragmentCatalogueBinding? = null
    private val binding get() = _binding
    private lateinit var listOfId: ArrayList<Int>

    private val movieViewModel: MovieViewModel by viewModel()
    private var initial = true

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setHasOptionsMenu(true)
    }

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {
        // Inflate the layout for this fragment
        _binding = FragmentCatalogueBinding.inflate(inflater, container, false)
        val view = binding?.root

        (activity as MainActivity).supportActionBar?.setDisplayHomeAsUpEnabled(true)

        return view
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)
        if (activity != null) {
            val movieAdapter = MovieAdapter(this)
            binding?.apply {
                with(recyclerview) {
                    layoutManager = LinearLayoutManager(context)
                    setHasFixedSize(true)
                    adapter = movieAdapter
                }
                swipeRefreshLayout.setColorSchemeColors(
                    Color.RED, Color.GREEN, Color.BLUE, Color.CYAN
                )
                swipeRefreshLayout.setOnRefreshListener { movieViewModel.isRefresh.value = true }
            }

            movieViewModel.movies.observe(viewLifecycleOwner, { movies ->
                if (movies != null) {
                    binding?.apply {
                        when (movies) {
                            is Resource.Loading -> progressBar.visibility = View.VISIBLE
                            is Resource.Success -> {
                                progressBar.visibility = View.GONE
                                swipeRefreshLayout.isRefreshing = false
                                movies.data?.let {
                                    movieAdapter.submitData(lifecycle, it)
                                }
                                movieAdapter.notifyDataSetChanged()
                            }
                            is Resource.Error -> {
                                progressBar.visibility = View.GONE
                                swipeRefreshLayout.isRefreshing = false
                                imgPlaceholder.visibility = View.VISIBLE
                                txtConnection.visibility = View.VISIBLE
                                Toast.makeText(context, movies.message, Toast.LENGTH_SHORT).show()
                            }
                        }
                    }
                }
            })

            movieAdapter.addLoadStateListener { loadState ->
                if (loadState.source.refresh is LoadState.NotLoading && loadState.append.endOfPaginationReached && movieAdapter.itemCount < 1) {
                    if (initial) {
                        movieViewModel.isRefresh.value = true
                    } else {
                        binding?.apply {
                            imgPlaceholder.setImageDrawable(
                                ContextCompat.getDrawable(
                                    requireActivity(),
                                    R.drawable.img_not_found
                                )
                            )
                            imgPlaceholder.visibility = View.VISIBLE
                            txtConnection.text = requireActivity().getString(R.string.data_not_found)
                            txtConnection.visibility = View.VISIBLE
                        }
                    }
                } else {
                    binding?.apply {
                        imgPlaceholder.visibility = View.GONE
                        txtConnection.visibility = View.GONE
                    }
                }
            }

            viewLifecycleOwner.lifecycleScope.launch {
                movieAdapter.loadStateFlow
                    .collectLatest { listOfId = listOfMovieId(movieAdapter.snapshot().items) }
            }
        }
    }

    override fun onCreateOptionsMenu(menu: Menu, inflater: MenuInflater) {
        inflater.inflate(R.menu.option_menu, menu)

        val searchManager =
            requireActivity().getSystemService(Context.SEARCH_SERVICE) as SearchManager
        val searchView = menu.findItem(R.id.search).actionView as SearchView

        val searchEditFrame: LinearLayout =
            searchView.findViewById<View>(R.id.search_edit_frame) as LinearLayout

        val params = LinearLayout.LayoutParams(
            LinearLayout.LayoutParams.MATCH_PARENT,
            LinearLayout.LayoutParams.MATCH_PARENT
        )
        params.marginStart = 0
        params.marginEnd = 0
        searchEditFrame.layoutParams = params

        searchView.setSearchableInfo(searchManager.getSearchableInfo(requireActivity().componentName))
        searchView.queryHint = resources.getString(R.string.search_hint)
        searchView.setOnQueryTextListener(object : SearchView.OnQueryTextListener {
            override fun onQueryTextSubmit(query: String): Boolean {
                movieViewModel.query.value = "SELECT * FROM movie_entities WHERE title LIKE '%$query%'"
                return true
            }

            override fun onQueryTextChange(newText: String): Boolean {
                if (newText.isNotEmpty()) {
                    initial = false
                    movieViewModel.query.value =
                        "SELECT * FROM movie_entities WHERE title LIKE '%$newText%'"
                } else movieViewModel.query.value = "SELECT * FROM movie_entities"
                return true
            }
        })

        super.onCreateOptionsMenu(menu, inflater)
    }

    private fun listOfMovieId(movies: List<Movie>?): ArrayList<Int> {
        val listId = ArrayList<Int>()
        if (movies != null) {
            for (movie in movies) {
                listId.add(movie.id)
            }
        }
        return listId
    }

    override fun onDestroyView() {
        super.onDestroyView()
        _binding = null
    }

    override fun onShareClick(movie: Movie) {
        if (activity != null) {
            val mimeType = "text/plain"
            ShareCompat.IntentBuilder(requireActivity())
                .setType(mimeType)
                .setChooserTitle(getString(R.string.text_share))
                .setText(resources.getString(R.string.share_text, movie.title))
                .startChooser()
        }
    }

    override fun onItemClick(movie: Movie) {
        val intent = Intent(requireContext(), DetailMovieActivity::class.java)
        intent.putExtra(DetailMovieActivity.EXTRA_ID, movie.id)
        intent.putExtra(DetailMovieActivity.EXTRA_LIST_ID, listOfId)
        requireActivity().startActivity(intent)
    }

}