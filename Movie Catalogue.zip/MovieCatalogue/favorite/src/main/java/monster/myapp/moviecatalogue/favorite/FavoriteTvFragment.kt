package monster.myapp.moviecatalogue.favorite

import android.content.Intent
import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.core.app.ShareCompat
import androidx.core.content.ContextCompat
import androidx.fragment.app.Fragment
import androidx.lifecycle.lifecycleScope
import androidx.paging.LoadState
import androidx.recyclerview.widget.ItemTouchHelper
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.google.android.material.snackbar.Snackbar
import kotlinx.coroutines.flow.collectLatest
import kotlinx.coroutines.launch
import monster.myapp.moviecatalogue.R
import monster.myapp.moviecatalogue.databinding.FragmentFavoriteBinding
import monster.myapp.moviecatalogue.core.ui.TvShowAdapter
import monster.myapp.moviecatalogue.catalogue.tv.TvShowViewModel
import monster.myapp.moviecatalogue.core.domain.model.TvShow
import monster.myapp.moviecatalogue.core.ui.ItemTvShowCallback
import monster.myapp.moviecatalogue.detail.DetailTvShowActivity
import org.koin.androidx.viewmodel.ext.android.viewModel

class FavoriteTvFragment : Fragment(), ItemTvShowCallback {

    private var _binding: FragmentFavoriteBinding? = null
    private val binding get() = _binding
    private lateinit var listOfId: ArrayList<Int>

    private val tvShowViewModel: TvShowViewModel by viewModel()
    private lateinit var tvShowAdapter: TvShowAdapter

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {
        // Inflate the layout for this fragment
        _binding = FragmentFavoriteBinding.inflate(inflater, container, false)

        return binding?.root
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)
        itemTouchHelper.attachToRecyclerView(binding?.recyclerview)

        if (activity != null) {
            tvShowAdapter = TvShowAdapter(this)
            binding?.let {
                with(it.recyclerview) {
                    layoutManager = LinearLayoutManager(context)
                    setHasFixedSize(true)
                    adapter = tvShowAdapter
                }
            }

            tvShowViewModel.getFavoredTvShows().observe(viewLifecycleOwner, { tvShows ->
                tvShowAdapter.submitData(lifecycle, tvShows)
                tvShowAdapter.notifyDataSetChanged()
            })

            tvShowAdapter.addLoadStateListener { loadState ->
                if (loadState.source.refresh is LoadState.NotLoading && loadState.append.endOfPaginationReached && tvShowAdapter.itemCount < 1) {
                    binding?.let {
                        it.imgPlaceholder.visibility = View.VISIBLE
                        it.txtFavorite.visibility = View.VISIBLE
                    }
                } else {
                    binding?.let {
                        it.imgPlaceholder.visibility = View.GONE
                        it.txtFavorite.visibility = View.GONE
                    }
                }
            }

            viewLifecycleOwner.lifecycleScope.launch {
                tvShowAdapter.loadStateFlow
                    .collectLatest { listOfId = listOfTvId(tvShowAdapter.snapshot().items) }
            }
        }
    }

    private fun listOfTvId(tvShows: List<TvShow>?): ArrayList<Int> {
        val listId = ArrayList<Int>()
        if (tvShows != null) {
            for (tvShow in tvShows) {
                listId.add(tvShow.id)
            }
        }
        return listId
    }

    override fun onDestroyView() {
        super.onDestroyView()
        _binding = null
    }

    override fun onShareClick(tvShow: TvShow) {
        if (activity != null) {
            val mimeType = "text/plain"
            ShareCompat.IntentBuilder(requireActivity())
                .setType(mimeType)
                .setChooserTitle(getString(R.string.text_share))
                .setText(resources.getString(R.string.share_text, tvShow.name))
                .startChooser()
        }
    }

    override fun onItemClick(tvShow: TvShow) {
        val intent = Intent(requireContext(), DetailTvShowActivity::class.java)
        intent.putExtra(DetailTvShowActivity.EXTRA_ID, tvShow.id)
        intent.putExtra(DetailTvShowActivity.EXTRA_LIST_ID, listOfId)
        requireActivity().startActivity(intent)
    }

    private val itemTouchHelper = ItemTouchHelper(object : ItemTouchHelper.Callback() {
        override fun getMovementFlags(
            recyclerView: RecyclerView, viewHolder: RecyclerView.ViewHolder
        ): Int = makeMovementFlags(0, ItemTouchHelper.LEFT)

        override fun onMove(
            recyclerView: RecyclerView,
            viewHolder: RecyclerView.ViewHolder,
            target: RecyclerView.ViewHolder
        ): Boolean = true

        override fun onSwiped(viewHolder: RecyclerView.ViewHolder, direction: Int) {
            if (view != null) {
                val swipedPosition = viewHolder.bindingAdapterPosition
                val tvShowEntity = tvShowAdapter.getSwipedData(swipedPosition)
                tvShowEntity?.let { tvShowViewModel.setFavorite(it, false) }
                val snackBar =
                    Snackbar.make(view as View, R.string.message_undo, Snackbar.LENGTH_LONG)
                snackBar.setAction(R.string.message_ok) { _ ->
                    tvShowEntity?.let { tvShowViewModel.setFavorite(it, true) }
                }.setActionTextColor(ContextCompat.getColor(requireContext(), R.color.colorAccent))
                    .show()
            }
        }
    })

}