package monster.myapp.moviecatalogue.favorite

import android.content.Intent
import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.core.app.ShareCompat
import androidx.core.content.ContextCompat
import androidx.fragment.app.Fragment
import androidx.lifecycle.lifecycleScope
import androidx.paging.LoadState
import androidx.recyclerview.widget.ItemTouchHelper
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.google.android.material.snackbar.Snackbar
import kotlinx.coroutines.flow.collectLatest
import kotlinx.coroutines.launch
import monster.myapp.moviecatalogue.R
import monster.myapp.moviecatalogue.databinding.FragmentFavoriteBinding
import monster.myapp.moviecatalogue.core.ui.MovieAdapter
import monster.myapp.moviecatalogue.catalogue.movie.MovieViewModel
import monster.myapp.moviecatalogue.core.domain.model.Movie
import monster.myapp.moviecatalogue.core.ui.ItemMovieCallback
import monster.myapp.moviecatalogue.detail.DetailMovieActivity
import org.koin.androidx.viewmodel.ext.android.viewModel

class FavoriteMovieFragment : Fragment(), ItemMovieCallback {

    private var _binding: FragmentFavoriteBinding? = null
    private val binding get() = _binding
    private lateinit var listOfId: ArrayList<Int>

    private val movieViewModel: MovieViewModel by viewModel()
    private lateinit var movieAdapter: MovieAdapter

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {
        // Inflate the layout for this fragment
        _binding = FragmentFavoriteBinding.inflate(inflater, container, false)

        return binding?.root
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)
        itemTouchHelper.attachToRecyclerView(binding?.recyclerview)

        if (activity != null) {
            movieAdapter = MovieAdapter(this)
            binding?.let {
                with(it.recyclerview) {
                    layoutManager = LinearLayoutManager(context)
                    setHasFixedSize(true)
                    adapter = movieAdapter
                }
            }

            movieViewModel.getFavoredMovies().observe(viewLifecycleOwner, { movies ->
                movieAdapter.submitData(lifecycle, movies)
                movieAdapter.notifyDataSetChanged()
            })

            movieAdapter.addLoadStateListener { loadState ->
                if (loadState.source.refresh is LoadState.NotLoading && loadState.append.endOfPaginationReached && movieAdapter.itemCount < 1) {
                    binding?.let {
                        it.imgPlaceholder.visibility = View.VISIBLE
                        it.txtFavorite.visibility = View.VISIBLE
                    }
                } else {
                    binding?.let {
                        it.imgPlaceholder.visibility = View.GONE
                        it.txtFavorite.visibility = View.GONE
                    }
                }
            }

            viewLifecycleOwner.lifecycleScope.launch {
                movieAdapter.loadStateFlow
                    .collectLatest { listOfId = listOfMovieId(movieAdapter.snapshot().items) }
            }
        }
    }

    private fun listOfMovieId(movies: List<Movie>?): ArrayList<Int> {
        val listId = ArrayList<Int>()
        if (movies != null) {
            for (movie in movies) {
                listId.add(movie.id)
            }
        }
        return listId
    }

    override fun onDestroyView() {
        super.onDestroyView()
        _binding = null
    }

    override fun onShareClick(movie: Movie) {
        if (activity != null) {
            val mimeType = "text/plain"
            ShareCompat.IntentBuilder(requireActivity())
                .setType(mimeType)
                .setChooserTitle(getString(R.string.text_share))
                .setText(resources.getString(R.string.share_text, movie.title))
                .startChooser()
        }
    }

    override fun onItemClick(movie: Movie) {
        val intent = Intent(requireContext(), DetailMovieActivity::class.java)
        intent.putExtra(DetailMovieActivity.EXTRA_ID, movie.id)
        intent.putExtra(DetailMovieActivity.EXTRA_LIST_ID, listOfId)
        requireActivity().startActivity(intent)
    }

    private val itemTouchHelper = ItemTouchHelper(object : ItemTouchHelper.Callback() {
        override fun getMovementFlags(
            recyclerView: RecyclerView, viewHolder: RecyclerView.ViewHolder
        ): Int = makeMovementFlags(0, ItemTouchHelper.RIGHT)

        override fun onMove(
            recyclerView: RecyclerView,
            viewHolder: RecyclerView.ViewHolder,
            target: RecyclerView.ViewHolder
        ): Boolean = true

        override fun onSwiped(viewHolder: RecyclerView.ViewHolder, direction: Int) {
            if (view != null) {
                val swipedPosition = viewHolder.bindingAdapterPosition
                val movieEntity = movieAdapter.getSwipedData(swipedPosition)
                movieEntity?.let { movieViewModel.setFavorite(it, false) }
                val snackBar =
                    Snackbar.make(view as View, R.string.message_undo, Snackbar.LENGTH_LONG)
                snackBar.setAction(R.string.message_ok) { _ ->
                    movieEntity?.let { movieViewModel.setFavorite(it, true) }
                }.setActionTextColor(ContextCompat.getColor(requireContext(), R.color.colorAccent))
                    .show()
            }
        }
    })

}