package monster.myapp.moviecatalogue.core.data.source.remote.network

import monster.myapp.moviecatalogue.core.BuildConfig
import okhttp3.OkHttpClient
import okhttp3.logging.HttpLoggingInterceptor
import retrofit2.Retrofit
import retrofit2.converter.gson.GsonConverterFactory
import retrofit2.converter.scalars.ScalarsConverterFactory
import java.util.concurrent.TimeUnit

/**
 * Created by robby on 07/05/21.
 */
class ApiClient {

    companion object {
        const val BASE_URL: String = BuildConfig.BASE_URL
    }

    private lateinit var retrofit: Retrofit

    fun getApiClient(): ApiService {
        val httpLoggingInterceptor = HttpLoggingInterceptor()
        //set log level
        httpLoggingInterceptor.setLevel(HttpLoggingInterceptor.Level.BODY)
        val builder = OkHttpClient.Builder()
        builder.connectTimeout(20, TimeUnit.MINUTES) // connect timeout
            .writeTimeout(30, TimeUnit.MINUTES) // write timeout
            .readTimeout(30, TimeUnit.MINUTES)
            .callTimeout(2, TimeUnit.MINUTES) // read timeout

        //add logging
        builder.addInterceptor(httpLoggingInterceptor).build()
        retrofit = Retrofit.Builder()
            .baseUrl(BASE_URL)
            .client(builder.build())
            .addConverterFactory(ScalarsConverterFactory.create())
            .addConverterFactory(GsonConverterFactory.create())
            .build()
        return retrofit.create(ApiService::class.java)
    }

}