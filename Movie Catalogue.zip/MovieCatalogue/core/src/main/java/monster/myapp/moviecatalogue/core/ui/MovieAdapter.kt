package monster.myapp.moviecatalogue.core.ui

import android.view.LayoutInflater
import android.view.ViewGroup
import androidx.paging.PagingDataAdapter
import androidx.recyclerview.widget.DiffUtil
import androidx.recyclerview.widget.RecyclerView
import com.bumptech.glide.Glide
import com.bumptech.glide.request.RequestOptions
import monster.myapp.moviecatalogue.core.BuildConfig
import monster.myapp.moviecatalogue.core.R
import monster.myapp.moviecatalogue.core.databinding.ItemRowCatalogueBinding
import monster.myapp.moviecatalogue.core.domain.model.Movie
import monster.myapp.moviecatalogue.core.utils.AppUtils

/**
 * Created by robby on 06/05/21.
 */
class MovieAdapter(private val callback: ItemMovieCallback) :
    PagingDataAdapter<Movie, MovieAdapter.ListViewHolder>(DIFF_CALLBACK) {

    companion object {
        private val DIFF_CALLBACK = object : DiffUtil.ItemCallback<Movie>() {
            override fun areItemsTheSame(oldItem: Movie, newItem: Movie): Boolean {
                return oldItem.id == newItem.id
            }

            override fun areContentsTheSame(oldItem: Movie, newItem: Movie): Boolean {
                return oldItem == newItem
            }
        }
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): ListViewHolder {
        val itemsMovieBinding = ItemRowCatalogueBinding.inflate(
            LayoutInflater.from(parent.context), parent, false
        )
        return ListViewHolder(itemsMovieBinding)
    }

    override fun onBindViewHolder(holder: ListViewHolder, position: Int) {
        getItem(position)?.let { holder.bind(it) }
    }

    fun getSwipedData(swipedPosition: Int): Movie? = getItem(swipedPosition)

    inner class ListViewHolder(private val binding: ItemRowCatalogueBinding) :
        RecyclerView.ViewHolder(binding.root) {
        fun bind(movie: Movie) {
            with(binding) {
                tvTitle.text = movie.title
                tvTitle.isSelected = true
                tvDescription.text = movie.overview
                tvRelease.text = AppUtils.formatDate(movie.release_date)
                btnShare.setOnClickListener { callback.onShareClick(movie) }
                itemView.setOnClickListener { callback.onItemClick(movie) }
                Glide.with(itemView.context)
                    .load(BuildConfig.IMG_URL + movie.poster_path)
                    .apply(
                        RequestOptions.placeholderOf(R.drawable.ic_image_search)
                            .error(R.drawable.ic_broken_image)
                    )
                    .into(imgPoster)
            }
        }
    }
}