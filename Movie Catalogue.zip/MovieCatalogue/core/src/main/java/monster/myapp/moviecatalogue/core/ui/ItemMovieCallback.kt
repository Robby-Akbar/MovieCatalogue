package monster.myapp.moviecatalogue.core.ui

import monster.myapp.moviecatalogue.core.domain.model.Movie

/**
 * Created by robby on 06/05/21.
 */
interface ItemMovieCallback {
    fun onShareClick(movie: Movie)
    fun onItemClick(movie: Movie)
}