package monster.myapp.moviecatalogue.core.ui

import monster.myapp.moviecatalogue.core.domain.model.TvShow

/**
 * Created by robby on 06/05/21.
 */
interface ItemTvShowCallback {
    fun onShareClick(tvShow: TvShow)
    fun onItemClick(tvShow: TvShow)
}