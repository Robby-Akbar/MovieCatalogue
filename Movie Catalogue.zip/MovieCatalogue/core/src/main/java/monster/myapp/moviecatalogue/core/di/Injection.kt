package monster.myapp.moviecatalogue.core.di

import android.content.Context
import monster.myapp.moviecatalogue.core.data.CatalogueRepository
import monster.myapp.moviecatalogue.core.data.source.local.LocalDataSource
import monster.myapp.moviecatalogue.core.data.source.local.room.CatalogueDatabase
import monster.myapp.moviecatalogue.core.data.source.remote.RemoteDataSource
import monster.myapp.moviecatalogue.core.data.source.remote.network.ApiClient
import monster.myapp.moviecatalogue.core.domain.repository.ICatalogueRepository
import monster.myapp.moviecatalogue.core.domain.usecase.CatalogueInteractor
import monster.myapp.moviecatalogue.core.domain.usecase.CatalogueUseCase
import monster.myapp.moviecatalogue.core.utils.AppExecutors

/**
 * Created by robby on 07/05/21.
 */
object Injection {

    private fun provideRepository(context: Context): ICatalogueRepository {
        val database = CatalogueDatabase.getInstance(context)
        val remoteDataSource = RemoteDataSource.getInstance(ApiClient().getApiClient())
        val localDataSource = LocalDataSource.getInstance(database.catalogueDao())
        val appExecutors = AppExecutors()

        return monster.myapp.moviecatalogue.core.data.CatalogueRepository.getInstance(remoteDataSource, localDataSource, appExecutors)
    }

    fun provideCatalogueUseCase(context: Context): CatalogueUseCase {
        val repository = provideRepository(context)
        return CatalogueInteractor(repository)
    }

}