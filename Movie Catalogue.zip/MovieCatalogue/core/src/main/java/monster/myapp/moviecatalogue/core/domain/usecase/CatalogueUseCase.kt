package monster.myapp.moviecatalogue.core.domain.usecase

import androidx.paging.PagingData
import kotlinx.coroutines.flow.Flow
import monster.myapp.moviecatalogue.core.data.Resource
import monster.myapp.moviecatalogue.core.domain.model.Movie
import monster.myapp.moviecatalogue.core.domain.model.TvShow

/**
 * Created by robby on 15/06/21.
 */
interface CatalogueUseCase {

    fun getAllMovies(isRefresh: Boolean, query: String): Flow<Resource<PagingData<Movie>>>
    fun getMovie(id: Int): Flow<Resource<Movie>>

    fun getAllTvShows(isRefresh: Boolean, query: String): Flow<Resource<PagingData<TvShow>>>
    fun getTvShow(id: Int): Flow<Resource<TvShow>>

    fun getFavoredMovies(): Flow<PagingData<Movie>>
    fun getFavoredTvShows(): Flow<PagingData<TvShow>>

    fun setFavoredMovie(movie: Movie, state: Boolean)
    fun setFavoredTvShow(tvShow: TvShow, state: Boolean)

}