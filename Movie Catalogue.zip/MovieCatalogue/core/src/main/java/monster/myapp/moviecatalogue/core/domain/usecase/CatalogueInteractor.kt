package monster.myapp.moviecatalogue.core.domain.usecase

import monster.myapp.moviecatalogue.core.domain.model.Movie
import monster.myapp.moviecatalogue.core.domain.model.TvShow
import monster.myapp.moviecatalogue.core.domain.repository.ICatalogueRepository

/**
 * Created by robby on 15/06/21.
 */
class CatalogueInteractor(
    private val catalogueRepository: ICatalogueRepository
) : CatalogueUseCase {

    override fun getAllMovies(isRefresh: Boolean, query: String) =
        catalogueRepository.getAllMovies(isRefresh, query)

    override fun getMovie(id: Int) = catalogueRepository.getMovie(id)

    override fun getAllTvShows(isRefresh: Boolean, query: String) =
        catalogueRepository.getAllTvShows(isRefresh, query)

    override fun getTvShow(id: Int) = catalogueRepository.getTvShow(id)

    override fun getFavoredMovies() = catalogueRepository.getFavoredMovies()

    override fun getFavoredTvShows() = catalogueRepository.getFavoredTvShows()

    override fun setFavoredMovie(movie: Movie, state: Boolean) =
        catalogueRepository.setFavoredMovie(movie, state)

    override fun setFavoredTvShow(tvShow: TvShow, state: Boolean) =
        catalogueRepository.setFavoredTvShow(tvShow, state)

}